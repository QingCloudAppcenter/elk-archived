'use strict';

// register and polyfill need to happen in this
// order and in separate files. Checkout each file
// for a much more detailed explaination
require('./register');
require('./polyfill');

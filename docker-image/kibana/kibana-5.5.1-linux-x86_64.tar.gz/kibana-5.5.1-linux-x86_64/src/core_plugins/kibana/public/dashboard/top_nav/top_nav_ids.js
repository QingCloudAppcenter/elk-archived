export const TopNavIds = {
  ADD: 'add',
  SHARE: 'share',
  OPTIONS: 'options',
  SAVE: 'save',
  EXIT_EDIT_MODE: 'exitEditMode',
  ENTER_EDIT_MODE: 'enterEditMode',
  CLONE: 'clone'
};

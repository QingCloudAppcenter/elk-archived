import 'plugins/kbn_doc_views/views/table';
import 'plugins/kbn_doc_views/views/json';

'use strict';

module.exports = require('@spalger/numeral');

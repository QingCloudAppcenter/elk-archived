'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _info_button = require('./info_button');

Object.defineProperty(exports, 'KuiInfoButton', {
  enumerable: true,
  get: function get() {
    return _info_button.KuiInfoButton;
  }
});

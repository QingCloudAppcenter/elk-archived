# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-06-22T01:10:33Z", "build_sha"=>"17472eeac58b28cc45b061c26abbb41e71755cae", "build_snapshot"=>false}